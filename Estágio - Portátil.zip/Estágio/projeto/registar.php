<?php
$dsn = "mysql:host=localhost;dbname=serviceCenter";
$user = "root";
$passwd = "";
$pdo = new PDO($dsn, $user, $passwd);
?>

<!DOCTYPE html>
<html lang="en">

<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Registar</title>
</head>
<body>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <body>
    <br>
        <div class="container">
            <div class="row">
                <div class="col-md-5 mx-auto">
                    <div id="first">
                        <div class="">
                            <div class="logo mb-3">
                                <div class="col-md-12 text-center">
                                    <h1>Service Center</h1>
                                </div>
                            </div>
                            <br>
                            <form action="login.php" method="post" name="registar">
                                <div class="form-group">
                                    <label>Nome</label>
                                    <br>
                                    <input type="text" name="nome" class="form-control" id="name" required placeholder="Insira o seu nome">
                                </div>
                                <br>
                                <div class="form-group">
                                    <label>Email</label>
                                    <br>
                                    <input type="text" name="email" class="form-control" id="email" required placeholder="Insira o seu nome">
                                </div>
                                <br>
                                <div class="form-group">
                                    <label>Password</label>
                                    <br>
                                    <input type="password" name="password" id="password" class="form-control" required placeholder="Insira a sua password">
                                </div>
                                <br>
                                <div class="col-md-12 text-center">
                                    <button type="submit" name="registar" class="btn btn-block mybtn btn-secondary tx-tfm">Registar</button>
                                </div>
                                <br>
                                <div class="form-group">
                                    <p class="text-center"> Já não tem conta? <a href="login.php" id="login">Iniciar sessão</a></p>
                                </div>
                            </form>
                            <?php
                            try {
                                if (isset($_POST['registar'])) {
                                    $name = $_POST['name'];
                                    $email = $_POST['email'];
                                    $password = $_POST['password'];
                                    $stm = $pdo->query("SELECT * FROM utilizadores WHERE name = '$name' AND email = '$email' AND password = '$password'");
                                    $row = $stm->fetch(PDO::FETCH_ASSOC);
                                    if (is_array($row)) {
                                        $_SESSION["name"] = $row['name'];
                                        $_SESSION["email"] = $row['email'];
                                        $_SESSION["password"] = $row['pass'];
                                    }
                                }
                                if (isset($_SESSION["email"])) {
                                    session_start();
                                    header("Location:login.php");
                                }
                            } catch (Exception $e) {
                                echo 'Erro ao registar!';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</body>
</html>