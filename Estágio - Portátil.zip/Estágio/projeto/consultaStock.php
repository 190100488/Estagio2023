<?php

$dsn = "mysql:host=localhost;dbname=serviceCenter";
$user = "root";
$passwd = "";
$pdo = new PDO($dsn, $user, $passwd);

if (isset($_POST['registoEquipamento'])) {

    $partNumber = $_POST['partNumber'];
    $serialNumber = $_POST['serialNumber'];
    $quantidade = $_POST['quantidade'];

    $data = [
        'partNumber' => $partNumber,
        'serialNumber' => $serialNumber,
        'quantidade' => $quantidade,
    ];

    $sql = "INSERT INTO equipamentos(partNumber, serialNumber, quantidade) VALUES (:partNumber, :serialNumber, :quantidade)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
}

if (isset($_GET["codEquipamento"])) {

    $stm = $pdo->query("SELECT * FROM equipamentos WHERE codEquipamento = " . $_GET["codEquipamento"]);
    $rows = $stm->fetchAll(PDO::FETCH_ASSOC);
    $equipamento = $rows[0];
} else {
    $equipamento["codEquipamento"] = "";
    $equipamento["partNumber"] = "";
    $equipamento["serialNumber"] = "";
    $equipamento["quantidade"] = "";
}

if (isset($_POST['editarEquipamento'])) {

    $codEquipamento = $_POST['codEquipamento'];
    $partNumber = $_POST['partNumber'];
    $serialNumber = $_POST['serialNumber'];
    $quantidade = $_POST['quantidade'];

    $data = [
        'codEquipamento' => $codEquipamento,
        'partNumber' => $partNumber,
        'serialNumber' => $serialNumber,
        'quantidade' => $quantidade,
    ];

    $sql = "UPDATE equipamentos SET partNumber = :partNumber, serialNumber = :serialNumber, quantidade = :quantidade WHERE codEquipamento = :codEquipamento";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
}

$stm = $pdo->query("SELECT * FROM equipamentos");
$rows = $stm->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Stock</title>
</head>

<body>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
    crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" 
    crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" 
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" 
    crossorigin="anonymous"></script>

    <header>
        <nav class="navbar navbar-dark bg-dark">
            <ul class="nav nav-pills">
                <li class="nav-item"><a href="serviceCenter.php" class="nav-link px-2 text-light">Service Center</a></li>
                <li class="nav-item"><a href="registoTrabalhos.php" class="nav-link px-2 text-secondary">Trabalhos</a></li>
                <li class="nav-item"><a href="consultaStock.php" class="nav-link px-1 text-light">Consulta Stock</a></li>
                <li class="nav-item"><a href="login.php" class="nav-link px-2 text-light">Sign out</a></li>
            </ul>
        </nav>
    </header>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Stock</h1>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 text-left">
                <form action="consultaStock.php" method="post">
                    <div class="form-group">
                        <label>Part Number</label>
                        <input type="text" required maxlength="150" name="partNumber" class="form-control" id="partNumber" 
                        value="<?= $equipamento["partNumber"] ?>">
                    </div><br>
                    <div class="form-group">
                        <label>Serial Number</label>
                        <input type="text" required maxlength="50" name="serialNumber" class="form-control" id="serialNumber" 
                        value="<?= $equipamento["serialNumber"] ?>">
                    </div><br>
                    <div class="form-group">
                        <label>Quantidade</label>
                        <input type="number" required min="0" name="quantidade" class="form-control" id="quantidade" 
                        value="<?= $equipamento["quantidade"] ?>">
                    </div><br>
                    <?php
                    if (isset($_GET["codEquipamento"])) {
                        printf("<div class='text-center mb-3'>
                        <button type='submit' name='editarequipamento' class='btn btn-block mybtn btn-secondary' tx-tfm>Editar
                        Equipamento</button>
                        </div>");
                    } else {
                        printf("<div class='text-center mb-3'>
                        <button type='submit' name='registoEquipamento' class='btn btn-block mybtn btn-secondary tx-tfm'>Registar
                        Equipamento</button>
                        </div>");
                    }
                    ?>
                </form>
            </div>
            <div class="col-md-9">
                <table class="table">
                    <tr>
                        <th scope="col">codEquipamento</th>
                        <th scope="col">partNumber</th>
                        <th scope="col">serialNumber</th>
                        <th scope="col">quantidade</th>
                        <th scope="col">*</th>
                    </tr>
                    <tbody class="table-group-divider">
                        <?php
                        foreach ($rows as $row) {
                            printf("<tr><td>{$row['codEquipamento']}</td>
                     <td>{$row['partNumber']}</td>
                     <td>{$row['serialNumber']}</td>
                     <td>{$row['quantidade']}</td>
                     <td><a class='editarEquipamento' href='consultaStock.php?codEquipamento={$row['codEquipamento']}'>Editar</a> | | <a class='editarEliminar' href='consultaStock.php?idDelete={$row['codEquipamento']}'>Eliminar</a></td><br>");
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>